import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/JustMev/foodtubeporn/master/home2.txt?token=AOJJ0pUjfF44Ft-wxTVKiov0LS9QLebqks5YLqZ1wA%3D%3D'
addon = xbmcaddon.Addon('plugin.video.foodtubeporn')
